# Acervo de fontes (texto completo)

Pergunta de pesquisa: O uso de containers afeta a eficiencia das pipelines de dados em ambientes de engenharia de dados de grande escala?

Total: 11 fontes (5 classicas e 6 recentes).

Os links abaixo levam ao texto completo de cada artigo. As fontes "Aberto" abrem o PDF direto.
As fontes "Restrito" devem ser acessadas pelo Portal de Periodicos CAPES com o login do IFRS, ou solicitadas ao autor no ResearchGate.

## Artigos-origem (seeds usados no Litmaps e no ResearchRabbit)
1. Di Tommaso et al. (2015), classico
2. Felter et al. (2015), classico
3. Pahl et al. (2019), classico (revisao)

## Classicos e mais citados

| # | Autor (ano) | Acesso | Texto completo |
|---|-------------|--------|----------------|
| C1 | Felter et al. (2015) | Aberto | https://people.computing.clemson.edu/~jmarty/projects/lowLatencyNetworking/papers/NFVandContainers/AnupdatedPerfAnalysisofContainersandVMs.pdf |
| C2 | Bernstein (2014) | Restrito | https://doi.org/10.1109/MCC.2014.51 |
| C3 | Di Tommaso et al. (2015) | Aberto | https://peerj.com/articles/1273.pdf |
| C4 | Boettiger (2015) | Aberto | https://arxiv.org/pdf/1410.0846 |
| C5 | Pahl et al. (2019) | Aberto | https://pooyanjamshidi.github.io/resources/papers/cloud-containers-tcc.pdf |

## Recentes (2020 a 2025)

| # | Autor (ano) | Acesso | Texto completo |
|---|-------------|--------|----------------|
| R1 | Santiago-Duran et al. (2020) | Restrito | https://doi.org/10.1016/j.future.2020.01.012 |
| R2 | Aurangzaib et al. (2022) | Restrito | https://doi.org/10.1109/CloudCom55334.2022.00014 |
| R3 | Soltanmohammadi; Hikmet (2024) | Aberto | https://www.scirp.org/journal/paperinformation?paperid=136659 |
| R4 | Gandhari (2025) | Aberto | https://www.theamericanjournals.com/index.php/tajet/article/view/6518 |
| R5 | Tiwari (2025) | Aberto | https://al-kindipublishers.org/index.php/jcsts |
| R6 | Olsson (2021) | Aberto | https://www.diva-portal.org/smash/get/diva2:1641422/FULLTEXT02.pdf |

## Resumo de cada fonte (para a leitura)

- C1 Felter et al. (2015): comparacao de desempenho entre maquinas virtuais (KVM) e containers (Docker). Containers empatam ou superam VMs na maioria dos testes, com overhead de CPU e memoria desprezivel.
- C2 Bernstein (2014): texto conceitual sobre a evolucao do LXC ate o Docker e o Kubernetes, situando containers e orquestracao na nuvem.
- C3 Di Tommaso et al. (2015): mede o overhead do Docker em pipelines genomicas reais. O impacto e minimo e desprezivel em tarefas longas.
- C4 Boettiger (2015): apresenta o Docker como ferramenta de reprodutibilidade em pesquisa, empacotando ambiente e dependencias.
- C5 Pahl et al. (2019): revisao sistematica das tecnologias de conteineres na nuvem, com mapeamento de trade-offs.
- R1 Santiago-Duran et al. (2020): modelo "gearbox" de pipeline em containers virtuais reduz tempos de resposta de 43% a 91%.
- R2 Aurangzaib et al. (2022): pipeline de IoT em Kubernetes com autoscaling, ganho de throughput de 1,31x a 2,4x e latencia menor de 32x a 80x.
- R3 Soltanmohammadi; Hikmet (2024): ETL em saude com PySpark e Docker (base MIMIC-III), com ganhos de tempo, recursos e escalabilidade.
- R4 Gandhari (2025): Kubernetes para ETL em producao, com reducao de tempo de execucao de ate 40% e economia de custo via autoscaling.
- R5 Tiwari (2025): boas praticas para pipelines resilientes e escalaveis em ambientes de multiplas nuvens.
- R6 Olsson (2021): estudo empirico de autoscaling (HPA e VPA) de big data em Kubernetes, medindo o overhead do escalonamento.
